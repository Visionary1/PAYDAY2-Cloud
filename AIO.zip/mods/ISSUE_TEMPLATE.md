Issue:

Crash log:

Mods running:

System information:
